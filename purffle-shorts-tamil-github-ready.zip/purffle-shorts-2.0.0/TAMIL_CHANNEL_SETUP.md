# Tamil Horror Shorts — setup notes for PurffleShorts 2.0.0

This package is the PurffleShorts Python application, customized with a Tamil-horror example configuration.

## Important platform limitation
GitHub Pages only hosts static websites. It cannot run this Python video-rendering program, FFmpeg jobs, or continuous upload automation. GitHub can store the source code; the app must run in a Python-capable environment (such as a computer or a suitable cloud runtime).

## Safe first run
1. Use Python 3.10 or newer and follow the installation steps in `README.md`.
2. Copy `.env.tamil.example` to `.env`.
3. Keep `UPLOAD=false` while testing. The example config is set not to upload videos automatically.
4. Try the built-in demo and render a local test video before connecting YouTube.
5. Set `CHANNEL_NAME` to your channel name. Keep `LANGUAGE=ta` and verify the voice sounds natural before rendering a full batch.
6. Do not upload API keys, `.env`, `credentials.json`, or other private credentials to GitHub. Keep them in your runtime's secret/environment-variable settings.

## YouTube publishing
Publishing requires configuring YouTube API OAuth credentials and explicitly authorizing the channel. Review every generated video, title, captions, visuals, and synthetic-media disclosure before publishing. Start with private or unlisted videos; do not enable unattended public uploads until the pipeline has been tested.

## Contents
- `README.md`: upstream documentation and full install instructions.
- `.env.tamil.example`: Tamil horror-oriented example settings with uploads disabled.
- `purffle_shorts/`: Python video generation pipeline and dashboard.
